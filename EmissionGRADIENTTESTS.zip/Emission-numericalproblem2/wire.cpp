#include<fstream>
#include<iostream>
#include<stdlib.h>
#include<math.h>

using namespace std;

int main () {
  double t=0; //time zero
  double tmax=1000;
  double dt=0.1;
  double v=1;
  int xmin=0;
  int xmax=31;
  int xmax2=30;
  int dx=1;
  double dy=dx;
  double R=5; //Radius of Circle 
  double Vmin=-100;
  double Vmax=100;
  char gauss_out_file[50];
  char grad_file[50];
  cout << "Please enter" << endl;

  cout << "Name of output file:" << endl;
  cin.getline ( gauss_out_file, 50 );

  ofstream gauss_out ( gauss_out_file );

  
  //create array of x and y values
  double xvalues[xmax];
  double yvalues[xmax];
  for (int i=xmin;i<xmax;i=i+dx){
    xvalues[i]=i;
    yvalues[i]=i;
  }
  int mid=(sizeof(xvalues)/sizeof(double))/2;

  //create array u0 to hold initial conditions
  double u0[xmax][xmax];
  double Amin=sqrt(Vmin*Vmin);
  double Amax=sqrt(Vmax*Vmax);
  double sidegrad=(Amin+Amax)/(double((sizeof(xvalues)/sizeof(double))));
  double k=Vmin;


  //u will hold the current time values, uplus will hold the n+1 time value
  //assume that first two arrays are the same!!!1!1!
  double u[xmax][xmax];
  double uplus[xmax][xmax];
  for(int i=xmin;i<xmax;i=i+dx){
    for(int j=xmin;j<xmax;j=j+dx){
      u[i][j]=0;
      uplus[i][j]=0;
    }
 }
  for(int i=xmin;i<xmax;i=i+dx){
    u[xmin][i]=Vmax;
    u[xmax2][i]=Vmin;
    //k=k+sidegrad;
    u[i][xmin]=-k;
    u[i][xmax2]=-k;
    k=k+sidegrad;
  }

  for(int i=xmin;i<xmax;i=i+dx){
    for(int j=xmin;j<xmax;j=j+dx){
      uplus[i][j]=u[i][j];
    }
  }

  double p=Vmin;
  //looping through time
    while (tmax >= t){

    //staggered leapfrog ~ iterating through grid
    for(int i=(xmin+1);i<(xmax-1);i=i+dx){
      for(int j=(xmin+1);j<(xmax-1);j=j+dx){
	
	       
	//boundary condition for circle
	if(((i-mid)*(i-mid))+((j-mid)*(j-mid))<(R*R)){
	  u[i][j]=0;
	  //	  cout << "ok circle" << endl;
	}
	
	uplus[i][j]=u[i][j]+((v*dt)/(dx*dx))*(u[(i+1)][j]-(2*u[i][j])+u[(i-1)][j]+u[i][(j+1)]-(2*u[i][j])+u[i][(j-1)]);
      }
    }
    for(int o=xmin;o<xmax;o=o+dx){
      for (int w=xmin;w<xmax;w=w+dx){
        u[o][w]=uplus[o][w];
      }
    }

    tmax=tmax-dt;
  }

    for(int o=xmin;o<xmax;o=o+dx){
      for (int w=xmin;w<xmax;w=w+dx){
        u[o][w]=uplus[o][w];
      }
    }

    for(int i=xmin;i<xmax;i=i+dx){
      u[xmin][i]=Vmax;
      u[xmax2][i]=Vmin;
      u[i][xmin]=-p;
      u[i][xmax2]=-p;
      p=p+sidegrad;
    }


  for(int i=0;i<31;i=i+dx){
    for(int j=0;j<31;j=j+dx){
      gauss_out << i << " " << j << " " << u[i][j]<< endl;;
    }
    gauss_out << " " << endl;
    }
  cout << "Done"<<endl;
  gauss_out.close();
  cout << u[0][0] << endl;




//GRADIENTSSSSS
  cout << "Name of output file for gradients:" << endl;
  cin.getline ( grad_file, 50 );

  ofstream grad ( grad_file );


//GRADIENT 
double ugradx[xmax2][xmax2];
double ugrady[xmax2][xmax2];
 
for(int o=xmin;o<xmax2;o=o+dx){
      for (int w=xmin;w<xmax2;w=w+dx){
		ugradx[o][w]=u[o][w]-u[o][(w+1)];
		ugrady[o][w]=u[o][w]-u[(o+1)][w];
      }
}
 
  for(int i=0;i<30;i=i+dx){
    for(int j=0;j<30;j=j+dx){
      grad  << xvalues[j] << " " << yvalues[i] << " " << ugradx[i][j] << " " << ugrady[i][j] << endl;;
    }
    grad << " " << endl;
    }
  cout << "Done"<<endl;
  grad.close();
  cout << u[0][0] << endl;

return 0;
}
