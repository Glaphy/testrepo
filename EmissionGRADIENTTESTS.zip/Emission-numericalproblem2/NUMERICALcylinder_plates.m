%TEST
%xmin and xmax are the spacial boundary conditions
%dx is the spacial steps
%tmax is the maximum time
%dt are the time steps

%set initial conditions
t=0; %time zero ~ where everything begins.....
tmax=50; %max time ~ longer time, greater accuracy
dt=0.1; %Time step
v=1; %this SHOULD BE 1
xmin=0; %grid size ~ this defines y rangge as well (they are the same)
xmax=30;
dx=1;   %spacial steps in x and y directions
dy=dx;
R=5;    %Radius of Circle

%xreate array of x and yvalues
xvalues=[xmin :dx :xmax];
yvalues=[xmin :dx :xmax];
%defining the midpoint to center the grounded cylinder 
mid = round(length(xvalues)/2);

%Create array u0 to hold initial conditions
u0=zeros(size(meshgrid(xvalues,yvalues)));
sidegrad=200/(length(xvalues)-1);
%boundary conditions ~ Parallel Plates
u0(1,:)=[-100:sidegrad:100];
u0(:,1)=-100;
u0(end,:)=[-100:sidegrad:100];
u0(:,end)=100;

%u will hold the current time values, uplus will hold the n+1 time value
%assume that first two arrays are the same
u=u0;
uplus=u0;

%looping through time
while t <= tmax
     
    %stager leapfrog ~ iterating through grid
    for i=2 : length(xvalues)-1
        for j= 2: length(xvalues)-1 
            %boundary conditions 
            u(1,:)=[-100:sidegrad:100];
            u(:,1)=-100;
            u(end,:)=[-100:sidegrad:100];
            u(:,end)=100;
            %BOUNDARY CONDITION FOR CIRCLE
            if ((i-mid)^2 + (j-mid)^2) < (R^2)
                u(i,j) = 0;
            end
            uplus(i,j)=u(i,j)+(dt*v/(dx*dx))*(u(i+1,j)-2*u(i,j)+u(i-1,j)+u(i,j+1)-2*u(i,j)+u(i,j-1));
        end
    end
    %iterating time and updating u;
    t=t+dt
    u=uplus;
end

figure(1)
%plotting
[xx,yy]=meshgrid(xvalues,yvalues);
surf(xx,yy,u)










