#!/bin/bash
gnuplot<<EOF
reset
set terminal png
set palette rgbformulae 22,13,-31
set output "grad.png"
set xrange [0:30]
set yrange [0:30]
plot "grad.dat" using 1:2:3:4 with vectors nofilled head lw 1
EOF


exit 0
