# Emission
The main codebase for the Emission project.

## Repository Etiquette:
1. Do not write to the master branch directly.
2. Create a pull request before merging with master.
3. Prune unecessary branches.
4. Try to Update the project board.
5. Praise our lord and savior Lucifer.
	
We can add things to this README as the project fleshes out.
