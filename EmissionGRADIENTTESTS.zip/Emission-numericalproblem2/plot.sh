#!/bin/bash
gnuplot<<EOF
set terminal png
set palette rgbformulae 22,13,-31
set output "laplace.png"
splot "laplace.dat"
EOF


exit 0
